export interface Ibooking {
    name: string,
    date: Date,
    service: string
}
