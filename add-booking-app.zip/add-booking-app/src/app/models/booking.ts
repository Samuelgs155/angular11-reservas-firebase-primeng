import { Ibooking } from "../interfaces/ibooking";
import * as _ from 'lodash';

export class Booking implements Ibooking{

    constructor(data){
        _.set(this, data);
    }
    
    get name(){
        return _.get(this, 'data.name');
    }

    get date(){
        return _.get(this, 'data.date');
    }

    get service(){
        return _.get(this, 'data.services');
    }

    getData(){
        return _.get(this, 'data');
    }
}
