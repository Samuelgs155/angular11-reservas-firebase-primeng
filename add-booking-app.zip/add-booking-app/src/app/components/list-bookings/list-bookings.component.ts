import { AuthService } from './../../services/auth.service';
import { BookingService } from './../../services/booking.service';
import { Component, OnInit } from '@angular/core';
import { Booking } from 'src/app/models/booking';
import { Ibooking } from 'src/app/interfaces/ibooking';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-bookings',
  templateUrl: './list-bookings.component.html',
  styleUrls: ['./list-bookings.component.css']
})
export class ListBookingsComponent implements OnInit {

  public listBookings: Ibooking[];
  public loadBookings: boolean;

  constructor(private bookingService: BookingService,
    private authService: AuthService,
    private router: Router) {
    this.listBookings = [];
    this.loadBookings = false;
   }

  ngOnInit(): void {

    if(this.authService.isAuthenticated()) {
      this.bookingService.getBookins().subscribe(
        list => {
          console.log(list);
          this.listBookings = list;
          this.loadBookings = true;
        }, error => {
          console.log('No se han podido recuperar las reservas.');
          this.loadBookings = true;
        }
      )
    } else {
      this.router.navigate(['/add-booking']);
    }
    
  }

}
