import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map} from 'rxjs/operators';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(infoLogin: any): Observable<boolean> {
    let headers = new HttpHeaders();
    headers = headers.set('Content-type', 'application/json');

    const url = 'https://booking-app-2ec27-default-rtdb.europe-west1.firebasedatabase.app/users.json';
    return this.http.get<any[]>(url, {headers: headers}).pipe(
      map(
        users => {
          let usuarios = [];
          usuarios = Object.values(users);
          let val = false;          
         /*  const user = _.find(usuarios, u => u.user === infoLogin.user && u.pass === infoLogin.pass); */ 
          /* const user = _.find(usuarios, u => u.user === infoLogin.user && u.pass === infoLogin.pass); */
          usuarios.forEach(element => {
            if(element.user === infoLogin.user && element.pass.toString() === infoLogin.pass) {
              val = true;
            }
          });
          if(val) {
            return true;
          }
          return false;
        }
      )
    );
  }

  isAuthenticated(){
    return localStorage.getItem('logged');
  }
}
