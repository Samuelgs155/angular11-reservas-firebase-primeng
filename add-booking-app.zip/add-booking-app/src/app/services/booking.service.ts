import { Booking } from './../models/booking';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Ibooking } from '../interfaces/ibooking';
import { map} from 'rxjs/operators';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http: HttpClient) { }

  addBooking(booking: any){
    let headers = new HttpHeaders();
    headers = headers.set('Content-type', 'application/json');

    const url = 'https://booking-app-2ec27-default-rtdb.europe-west1.firebasedatabase.app/bookings.json';

    /* const body = JSON.stringify(booking.getData()); */
    const body = booking;
    return this.http.post(url, body, {headers: headers});
  }

  getBookins(): Observable<Ibooking[]> {
    let headers = new HttpHeaders();
    headers = headers.set('Content-type', 'application/json');

    const url = 'https://booking-app-2ec27-default-rtdb.europe-west1.firebasedatabase.app/bookings.json';

    return this.http.get<Ibooking>(url,{headers:headers}).pipe(
      map(data => {
        let bookings = [];
        if(data) {
          const today = new Date();
          _.forEach(_.keys(data), key => {
            const booking = new Booking(data[key]);
            const bookingDate = new Date(data[key].date);
            if(bookingDate.getTime() >= today.getTime()){
              let book = {"name": data[key].name, "date": data[key].date, "services": data[key].services};
              bookings.push(book);
            }            
          });
        }
        bookings = _.orderBy(bookings, b => b.date);
        return bookings;
      })
    )

  }
}
